import { Component } from '@angular/core';

@Component({
  selector: 'app-discovercourse',
  templateUrl: './discovercourse.component.html',
  styleUrls: ['./discovercourse.component.css']
})
export class DiscovercourseComponent {

}
